Notes:

 - The login.php file goes in the the frog/app/views/login folder of your Frog installation. I'd recommend backing up your existing file to login_old.php or similar.

 - The files in the img folder go in admin/images.

 - The login.css file goes in admin/stylesheets. You'll want to the tweak the colors in the login.css file to your liking, as they apply to the color scheme of my own project, not Frog in general.

 - The scripts in the js folder should probably go in your admin folder in a folder of your choosing.

 - Please be aware that the files will not work as a stand-alone demo, as the login.php is dependent on interal Frog functions.

 - Also, please note I am not responsbile, yada yada yada. You know the rules, I'm not accountable and the files are provided as-is. 