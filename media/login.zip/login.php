<!-- 
	This is all the files combined, which is very poor for a production environment. When you use this file in a project, be sure to make the CSS, Javascript, and images external. The files are all included in the zip.
-->
<?php
/**
 * Frog CMS - Content Management Simplified. <http://www.madebyfrog.com>
 * Copyright (C) 2008 Philippe Archambault <philippe.archambault@gmail.com>
 * Copyright (C) 2008 Martijn van der Kleijn <martijn.niji@gmail.com>
 *
 * This file is part of Frog CMS.
 *
 * Frog CMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Frog CMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Frog CMS.	 If not, see <http://www.gnu.org/licenses/>.
 *
 * Frog CMS has made an exception to the GNU General Public License for plugins.
 * See exception.txt for details and the full text.
 */

/**
 * @package frog
 * @subpackage views
 *
 * @author Philippe Archambault <philippe.archambault@gmail.com>
 * @version 0.1
 * @license http://www.gnu.org/licenses/gpl.html GPL License
 * @copyright Philippe Archambault, 2008
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Member Login</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	
	<link href="themes/<?php echo Setting::get('theme'); ?>/styles.css" id="css_theme" media="screen" rel="Stylesheet" type="text/css" />
	<link href="stylesheets/login.css" rel="stylesheet" type="text/css" />
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script><!-- I like jQuery better ;) -->
	<script src="http://www.kryogenix.org/code/browser/labelify/jquery.labelify.js" type="text/javascript"></script><!-- Plugin should be d/led to your server in a production environment.  -->
	<script type="text/javascript"> // script should be external in a production environment
	$(function() { // the reason for the two functions is to appear to the user as if the fadeIn()s are happening simultaneously
		function switch_boxes(out, in_str) {
			return function() {
				$(out).fadeOut("fast", function() {
					$(in_str).fadeIn();
				});
			};
		}
		
		function switch_text(out, text) {
			return function() {
				$(out).fadeOut("fast", function() {
					$(this).html(text).fadeIn();
				});
				document.title = '' + text + ''; // change the page title in accordance with the current form action
			};
		}

		// page and dialog box titles that get switched
		var recover_text = "Password Recovery";
		var login_text = "Member Login";
	
		$("input").labelify({ text: "label", labelledClass: "inside" }); // Place input labels within inputs
		
		/*
		$("#login-username","fieldset").focus();
		$("#forgot").click(function() { $("#forgot-email", "fieldset").focus(); });
		$("#login").click(function() { $("#login-username", "fieldset").focus(); });
		Disabled because user needs to see label text within input, and focus() hides this text. Re-enable if you move labels back out of inputs
		*/
		
		$("#forgot").click( switch_boxes("#cms_login", "#pw_recover") );
		$("#forgot").click( switch_text("#dialog h2", recover_text) );
		$("#login").click( switch_boxes("#pw_recover", "#cms_login") );
		$("#login").click( switch_text("#dialog h2", login_text) );
	});
	</script>
</head>
<body>
	<div id="dialog">
		<h2>Member Login</h2>
		
		<?php if (Flash::get('error') !== null) { ?>
			<div id="error"><?php echo Flash::get('error'); ?></div>
			<script type="text/javascript">
			$(function() { 
				$("#error").fadeIn().animate({ opacity: 1.0 },4000).fadeOut(); // the animate function is just a jQuery hack to simulate a delay
			});
			</script>
		<?php } ?>
		
		<?php if (Flash::get('success') != null) {	 ?>
			<div id="success"><?php echo Flash::get('success'); ?></div>
			<script type="text/javascript">
			$(function() { 
				$("#success").fadeIn().animate({ opacity: 1.0 },4000).fadeOut(); // see above
			});
			</script>
		<?php } ?>
		
		<div id="form-wrap">
			<form id="cms_login" action="<?php echo get_url('login/login'); ?>" method="post">
				<fieldset>
					<label for="login-username"><?php echo __('Username'); ?></label>
					<input id="login-username" class="medium" type="text" name="login[username]" value="" />
					
					<label for="login-password"><?php echo __('Password'); ?></label>
					<input id="login-password" class="medium" type="password" name="login[password]" value="" />
					
					<input class="submit" type="submit" accesskey="s" value="<?php echo __('Login'); ?>" />
				</fieldset>
				<div class="clean"></div>
				<div class="bottom">
					<fieldset>
						<input id="login-remember-me" type="checkbox" class="checkbox" name="login[remember]" value="checked" />
						<input id="login-redirect" type="hidden" name="login[redirect]" value="<?php echo $redirect; ?>" />
						<label class="checkbox" for="login-remember-me"><?php echo __('Remember me'); ?></label> | 
						<a id="forgot" href="#"><?php echo __('Forgot password?'); ?></a>
					</fieldset>
				</div>
			</form>
			<form id="pw_recover" action="<?php echo get_url('login', 'forgot'); ?>" method="post"><!-- The password recovery form, copied from the forgot.php view. It is hidden with CSS. -->
				<fieldset>
					<label for="forgot-email"><?php echo __('Enter your email'); ?>:</label>
					<input class="medium" id="forgot-email" type="text" name="forgot[email]" value="<?php echo $email; ?>" />
					<input class="submit" type="submit" accesskey="s" value="<?php echo __('Reset password'); ?>" />
				</fieldset>
				<div class="clean"></div>
				<div class="bottom">
					<a id="login" href="#"><?php echo __('&lArr; Back to login'); ?></a>
				</div>
			</form>
		</div>
	</div>
</body>
</html>