$(function() { // the reason for the two functions is to appear to the user as if the fadeIn()s are happening simultaneously
	function switch_boxes(out, in_str) {
		return function() {
			$(out).fadeOut("fast", function() {
				$(in_str).fadeIn();
			});
		};
	}
	
	function switch_text(out, text) {
		return function() {
			$(out).fadeOut("fast", function() {
				$(this).html(text).fadeIn();
			});
			document.title = '' + text + ''; // change the page title in accordance with the current form action
		};
	}

	// page and dialog box titles that get switched
	var recover_text = "Password Recovery";
	var login_text = "Member Login";

	$("input").labelify({ text: "label", labelledClass: "inside" }); // Place input labels within inputs
	
	/*
	$("#login-username","fieldset").focus();
	$("#forgot").click(function() { $("#forgot-email", "fieldset").focus(); });
	$("#login").click(function() { $("#login-username", "fieldset").focus(); });
	Disabled because user needs to see label text within input, and focus() hides this text. Re-enable if you move labels back out of inputs
	*/
	
	$("#forgot").click( switch_boxes("#cms_login", "#pw_recover") );
	$("#forgot").click( switch_text("#dialog h2", recover_text) );
	$("#login").click( switch_boxes("#pw_recover", "#cms_login") );
	$("#login").click( switch_text("#dialog h2", login_text) );
});